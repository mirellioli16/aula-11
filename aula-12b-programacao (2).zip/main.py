

import math
print(math.factorial(6))
print('\n\n')
#===================================atv5 trabalhando com dicionario media
classe = {"Ana": 4.5,
           "Beatriz": 6.5,
           "Geraldo": 1.0,
            "José": 10.0,
             "maria": 9.5}
notas = classe.values()
média = sum(notas)/5
print("A média da classe é",média)

#===========================================atv4 dicionario salgado
dic= {"Salgado":4.50,
"Lanche": 6.50,
 "Suco": 3.00,
"Refrigente": 3.50,
"Doce": 1.00}
print('\n\n')
#=======================================atv3 dicionario salgadoslanchonete
D = {"arroz": 17.30,"feijão": 12.50,"carne": 23.90,"alface": 3.40} 
print(D) 

D["carne"] = 25.0
D["tomate"] = 8.80
print(D)
print('\n\n')




#=============================atv2 trabalhando com Tuplas
T = (10,20,30,40,50)
a,b,c,d,e= T 
print("a =",a,"b =",b)
print("d + e =" ,d+e)
print('\n\n')

#=================================atv1 praticando por lista
L = [5, 7, 2, 9, 4, 1, 3]
print("Lista = ",L)
print("O tamanho da lista é ",len(L))
print("O maior elemento da lista é",max(L))
print("O menor elemento da lista é",min(L))
print("A soma dos elementos da lista é ",sum(L))
L.sort()
print("Lista em ordem crescente: ",L)
L.reverse()
print("Lista em ordem decrescente: ",L)
print('\n\n')